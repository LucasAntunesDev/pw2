<?php

interface Propietario{
    public function obterLucros();
}