<?php

interface Colaborador{
    public function trabalhar();
}