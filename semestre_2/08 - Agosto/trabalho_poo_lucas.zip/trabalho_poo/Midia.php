<?php

interface Midia {

    public function getDuracao();
    public function setDuracao($duracao);
}
